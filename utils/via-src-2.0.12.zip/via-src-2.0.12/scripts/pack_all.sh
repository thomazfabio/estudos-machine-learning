#!/bin/sh
python3 pack_via.py
python3 pack_demo.py
python3 pack_demo.py face
python3 pack_demo.py wikimedia
